#include "mainwindow.h"
#include "ui_mainwindow.h"




MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // insert a row ;

   // int row = ui->alarm_table->rowCount();

   //  ui->alarm_table->insertRow(row);

   // qDebug("%d",);

    ui->alarm_table->horizontalHeader()->setStretchLastSection(true);

    ui->Configure_ndoe->setEnabled(false);

    this->server = new Server();

    server->init(8888);

    connect(server,SIGNAL(readMsg()),this,SLOT(AddOneRow()));


    database = new DataBase();

    database->createConnection();

    database->createTable();


 //   this->ininServer();
}

MainWindow::~MainWindow()
{
    delete ui;
}


void  MainWindow::AddOneRow(){

    int row = ui->alarm_table->rowCount();

    ui->alarm_table->insertRow(row);

    static int index = 1;

   // row = ui->alarm_table->rowCount();

    QTableWidgetItem *item0,*item1,*item2,*item3,*item4;

    item0 = new QTableWidgetItem;
    item1 = new QTableWidgetItem;
    item2 = new QTableWidgetItem;
    item3 = new QTableWidgetItem;
    item4 = new QTableWidgetItem;




    item0->setText(QString::number(index,10));
    ui->alarm_table->setItem(row,0,item0);

    QStringList msg = QString(this->server->rcvmsg).split(";");
    QString tmp[msg.length()];

    int tindex=0;

    foreach(QString str,msg){

        QStringList data = str.split(":");
        qDebug()<<data.at(0);
        qDebug()<<data.at(1);
        tmp[tindex++]=data.at(1);
    }

    //qDebug()<<QString(this->server->rcvmsg);

    if(tmp[2]=="11"){

         ui->Configure_ndoe->setEnabled(true);
         qDebug()<<"enable configure button";

    }else{

        item1->setText(tmp[0]);
        ui->alarm_table->setItem(row,1,item1);

        item2->setText(tmp[1]);
        ui->alarm_table->setItem(row,2,item2);

        item3->setText(tmp[2]);
        ui->alarm_table->setItem(row,3,item3);


        QDateTime current_date_time = QDateTime::currentDateTime();
        QString   current_date = current_date_time.toString("yyyy-MM-dd hh:mm:ss ddd");
        item4->setText(current_date);
        ui->alarm_table->setItem(row,4,item4);

        ++index;
    }



};

void MainWindow::on_Configure_ndoe_clicked()
{

}

void MainWindow::on_pushButton_2_clicked()
{
    QString nodeid = ui->nodeid_lineedit->text();

    int tmpid = 0;
    nodeid.number(tmpid,10);

    QString nodeaddr = database->queryById(tmpid);



    ui->nodeaddr_lineedit->setText(nodeaddr);



}
