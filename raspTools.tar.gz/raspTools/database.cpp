
#include "database.h"


bool DataBase::createConnection()
{

    db = QSqlDatabase::addDatabase("QSQLITE", "sqlite1");
    db.setDatabaseName(".//qtDb.db");
    if( !db.open())
    {
        qDebug() << "open database failure";
        return false;
    }
    return true;
}


bool DataBase::createTable()
{

    QSqlQuery query(db);

    bool isTableExist = \
            query.exec(QString("select count(*) from sqlite_master where type='table' and name='%1'"));

    if(!isTableExist){

        bool success = query.exec("create table nodedata(nodeid int primary key,"
                                  "nodeaddr varchar(100))");
        if(success)
        {
            qDebug() << QObject::tr("create table");
            return true;
        }
        else
        {
            qDebug() << QObject::tr("create table failure");
            return false;
        }
    }else{

        qDebug()<<"table is exist";
    }
}

bool DataBase::insert()
{
    QSqlQuery query(db);
    query.prepare("insert into nodedata values(?, ?)");

    long records = 10;
    for(int i=0; i<records; i++)
    {
        query.bindValue(0, i);
        query.bindValue(1, "sichuang chengdu");


        bool success=query.exec();
        if(!success)
        {
            QSqlError lastError = query.lastError();
            qDebug() << lastError.driverText() << QString(QObject::tr("insert error"));
            return false;
        }
    }
    return true;
}

bool DataBase::queryAll()
{

    QSqlQuery query(db);
    query.exec("select * from nodedata");
    QSqlRecord rec = query.record();
    qDebug() << QObject::tr("nodedata query" ) << rec.count();

    while(query.next())
    {
        for(int index = 0; index < 2; index++)
            qDebug() << query.value(index) << " ";
        qDebug() << "\n";
    }
}


bool DataBase::deleteById(int id)
{

    QSqlQuery query(db);
    query.prepare(QString("delete from nodedata where nodeid=%1").arg(id));
    if(!query.exec())
    {
        qDebug() << "delete failure";
        return false;
    }
    return true;
}

bool DataBase::updateById(int id)
{
    QSqlQuery query(db);
    query.prepare(QString("update nodedata set nodeid=?, nodeaddr=? where nodeid=%1").arg(id));


    query.bindValue(0,id);
    query.bindValue(1,"abce");


     bool success=query.exec();
     if(!success)
     {
          QSqlError lastError = query.lastError();
          qDebug() << lastError.driverText() << QString(QObject::tr("query failure"));
     }
    return true;
}

QString  DataBase::queryById(int id)
{

    QSqlQuery query(db);

    QString value = query.value(id).toString();

    return value;


}


bool DataBase::sortById()
{
    QSqlQuery query(db);
    bool success=query.exec("select * from nodedata order by id desc");
    if(success)
    {
        qDebug() << QObject::tr("success");
        return true;
    }
    else
    {
        qDebug() << QObject::tr("failure");
        return false;
    }
}
