#ifndef MAINWINDOW_H
#define MAINWINDOW_H



#include "server.h"
#include "database.h"
#include <QDateTime>
#include <QMainWindow>
#include <QtNetwork/QTcpServer>
#include <QtNetwork/QHostAddress>
#include <QtNetwork/QTcpSocket>

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
   // void ininServer();

private:
    Ui::MainWindow *ui;
    QString    rcvMsg;
    Server *server;
    DataBase  *database;
private slots:

    void  AddOneRow();
   //void  Connection();
   //void  processText();

    void on_Configure_ndoe_clicked();
    void on_pushButton_2_clicked();
};

#endif // MAINWINDOW_H

