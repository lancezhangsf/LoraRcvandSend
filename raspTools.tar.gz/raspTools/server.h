#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>
#include <QMessageBox>
#include <QDebug>
#include <QNetworkInterface>

class Server : public QObject
{
    Q_OBJECT
public:
    QString rcvmsg;
    explicit Server(QObject *parent = 0);
    ~Server();

    void init( int port);
    void sendData(QString ip, QString data);
    void sendData(QString ip, uchar *rawData);

signals:

    void readMsg();

private slots:

    void newConnectSlot();

    void removeUserFormList();

    void  readMessage();
private:
    QTcpServer *m_tcpServer;

    QMap<QString, QTcpSocket *> m_mapClient;

};
