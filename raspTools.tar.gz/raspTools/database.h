
#ifndef DATABASE_H
#define DATABASE_H

#include <QTextCodec>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QTime>
#include <QSqlError>
#include <QtDebug>
#include <QSqlDriver>
#include <QSqlRecord>

class DataBase
{
public:
    bool createConnection();
    bool createTable();
    bool insert();
    bool queryAll();
    bool updateById(int id);
    bool deleteById(int id);
    bool sortById();
    QString queryById(int id);

 public:

    QSqlDatabase db;
};

#endif // DATABASE_H
