#include "server.h"
#include <qdebug.h>
#include <QMessageBox>

Server::Server(QObject *parent) : QObject(parent)
{
    m_tcpServer = new QTcpServer();


    m_tcpServer->setMaxPendingConnections(2000);
//    QDBG << m_tcpServer->maxPendingConnections();
    connect(m_tcpServer,SIGNAL(newConnection()),this,SLOT(newConnectSlot()));

}

Server::~Server()
{

}

void Server::init( int port)
{

    if(m_tcpServer->listen(QHostAddress::Any, port)){
        qDebug() << "listen OK!";
    }else{
        qDebug() << "listen error!";
    }
}

void Server::sendData(QString ip, QString data)
{
    m_mapClient.value(ip)->write(data.toLatin1());
}
void Server::sendData(QString ip, uchar *rawData)
{
    m_mapClient.value(ip)->write(QByteArray((char*)rawData));
}

void Server::newConnectSlot()
{
    QTcpSocket *tcp = m_tcpServer->nextPendingConnection();
    connect(tcp,SIGNAL(readyRead()),this,SLOT(readMessage()));
    m_mapClient.insert(tcp->peerAddress().toString(), tcp);

    qDebug()<<tcp->peerAddress();


   // QMessageBox  message(QMessageBox::Information,tr("information"),tcp->peerAddress().toString(),QMessageBox::Ok,NULL);


    //m_pMsgHandler->devOnline(tcp->peerAddress().toString());

    connect(tcp,SIGNAL(disconnected()),this,SLOT(removeUserFormList()));

}

void  Server::readMessage()
{

    QTcpSocket *socket = static_cast<QTcpSocket*>(sender());
   // qDebug() <<QString(socket->readAll()) ;



    this->rcvmsg = QString(socket->readAll());
    emit readMsg();

   // QMessageBox message(QMessageBox::Information,"info",QString(socket->readAll()),QMessageBox::Ok);
   // m_pMsgHandler->recvFromServer(socket->peerAddress().toString(), QString(socket->readAll()));
}

void Server::removeUserFormList()
{
    QTcpSocket* socket = static_cast<QTcpSocket*>(sender());

    QMap<QString, QTcpSocket *>::iterator it;

    for(it=m_mapClient.begin();it!=m_mapClient.end();it++)
    {
        if(socket->peerAddress().toString() == it.key())
        {
            m_mapClient.erase(it);
            QMessageBox message(QMessageBox::Information,"Addr",socket->peerAddress().toString());
            break;
        }
    }
}
